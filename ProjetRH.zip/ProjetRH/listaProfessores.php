<?php 
	include("cabecalho.php");
?>
 	<!-- conteudo principal -->
	<article class="coluna80">
		<section class="lista">
		<ul>
<?php
	include("professores.php");

	$lista = listaProfessores();

	foreach ($lista as $professor) {
?>	
	<div class="lista-professor">
		<li><a href="detalhaProfessor.php?cod=<?=$professor['Siape'] ?>"> <?=$professor['Nome'] ?></a></li>
	</div>
<?php
	}
?>
		 </ul>
		</section>
	</article>


<?php
	include("rodape.php");

?>	