<?php 
	include("cabecalho.php");

	include("alunos.php");
?>
 	<!-- conteudo principal -->
	<article class="coluna80">
		<section class="lista">
		<ul>
<?php
	$lista = listaAlunosTurma('1info1');

	foreach ($lista as $aluno) {
?>	
	<div class="lista-aluno">
		<li><a href="detalhaAluno.php?cod=<?=$aluno['Matricula'] ?>"> <?=$aluno['Nome'] ?></a></li>
	</div>
<?php
	}
?>
		 </ul>
		</section>
		<section class="lista">
<?php
	$lista = listaAlunosTurma('1info2');

	foreach ($lista as $aluno) {
?>	
	<div class="lista-aluno">
		<li><a href="detalhaAluno.php?cod=<?=$aluno['Matricula'] ?>"> <?=$aluno['Nome'] ?></a></li>
	</div>
<?php
	}
?>
		 </ul>
		</section>
		<section class="lista">
		<?php
	$lista = listaAlunosTurma('1info3');

	foreach ($lista as $aluno) {
?>	
	<div class="lista-aluno">
		<li><a href="detalhaAluno.php?cod=<?=$aluno['Matricula'] ?>"> <?=$aluno['Nome'] ?></a></li>
	</div>
<?php
	}
?>
		 </ul>
		</section>		
	</article>


<?php
	include("rodape.php");

?>	