<?php 	

 // ARQUIVO COM AS FUNÇÕES DOS ALUNOS



///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////                   LISTONA DOS ALUNOS                          //////////////////////////  
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	function listaAlunos(){

		$alunos = array();

		$dados = file("dados/alunos.csv");

		foreach ($dados as $posicao => $linha) {
			if ($posicao != 0) {
				$colunas = explode(",", $linha);

				$aluno = array();
	       		$aluno['Matricula'] = $colunas[0];
				$aluno['Nome']      = $colunas[1];
				$aluno['Turma']     = $colunas[2];
				$aluno['Email']     = $colunas[3];
				$aluno['Foto']      = $colunas[4];


				$alunos[] = $aluno;
			}
		}
		return $alunos;
}		
		//olha o array aí Í!!!!1!
	

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////                        BUSCA OS ALUNO                           //////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	function buscaAluno($matricula){
		$alunos = array();

		$dados = file("dados/alunos.csv");

		foreach ($dados as $linha) {

			$colunas = explode(",", $linha);

			if ($colunas[0] == $matricula) {

				$aluno['Matricula'] = $colunas[0];
				$aluno['Nome']      = $colunas[1];
				$aluno['Turma']     = $colunas[2];
				$aluno['Email']     = $colunas[3];
				$aluno['Foto']      = $colunas[4];

			}
		}

		return $aluno;
	}



////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////                     LISTA ALUNOS TURMA                          ///////////////////////// 
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


   	function listaAlunosTurma($turma){

   		$dados = file("dados/alunos.csv");
   		foreach ($dados as $posicao => $linha) {
   			if ($posicao !=0) {
   				$colunas = explode(",", $linha);
   				if ($colunas[2] == $turma) {

   					$aluno = array();

   					$aluno['Matricula'] = $colunas[0];
					$aluno['Nome']      = $colunas[1];
					$aluno['Turma']     = $colunas[2];
					$aluno['Email']     = $colunas[3];
					$aluno['Foto']      = $colunas[4];

					$alunos[] = $aluno;

   				}
   			}
   		}

   		return $alunos;
}
?>


