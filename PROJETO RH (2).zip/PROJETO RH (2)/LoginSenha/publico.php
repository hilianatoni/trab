<!DOCTYPE html>
<html>
<head>
	<title> bacana </title>
</head>
<body>
	<form method="post" action="login.php">
	
	<h2> Págino de Acessar Publicamente </h2>

		<label for="login">Login: </label>
		<input type="text" name="login">

		<label for="senha">Senha: </label>
		<input type="password" name="senha">

		<input type="submit" name="enviar">

	</form>
</body>
</html>