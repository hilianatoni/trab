<?php 
	include("cabecalho.php");
?>
	<!-- conteudo principal -->
	<article class="coluna80">
		<section class="foto">
			<img src="imagens/pessoa.png">
		</section>
		<section class="dados">

<?php
	include("professores.php");

	include("disciplinas.php");

	$siape = $_GET['cod'];

	$professor = buscaProfessor($siape);
?>

	<div class="detalhes-professor">
		<p>Nome: <?=$professor['Nome'] ?></p>
		<p>Email: <?=$professor['Email'] ?></p>
	</div>

		</section>
	</article>

<?php
	include("rodape.php");

?>	