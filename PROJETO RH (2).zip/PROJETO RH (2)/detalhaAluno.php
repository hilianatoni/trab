<?php 
	include("cabecalho.php");
?>

<article class="coluna80">
		<section class="foto">
			<img src="imagens/pessoa.png">
		</section>
		<section class="dados">

<?php
	include("alunos.php");

	$matricula = $_GET['cod'];

	$aluno = buscaAluno($matricula);
?>

		<p>Matrícula: <?=$aluno['Matricula'] ?></p>
		<p>Nome: <?=$aluno['Nome'] ?></p>
		<p>Email: <?=$aluno['Email'] ?></p>
		<p>Turma: <?=$aluno['Turma'] ?></p>

		</section>
	</article>


<?php
	include("rodape.php");

?>	