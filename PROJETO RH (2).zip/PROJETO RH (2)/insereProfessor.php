<pre>
<?php
	
	print_r($_POST);

	print_r($_FILES);

	$caminho_temporario = $_FILES['foto']['tmp_name'];

	$destino = "imagens/professores/".$_FILES['foto']['name'];

	$data = date('d/m/Y - H:i:s');

	move_uploaded_file($caminho_temporario, $destino);

















	// $siape = $_POST['siape'];
	// $nome = $_POST['nome'];
	// $email = $_POST['email'];
	// $foto = $_POST['foto'];

	//Linha que será escrita no CSV

	// $linha = "\n".$siape.",".$nome.",".$email.",".$foto;

	//OBSERVAR PERMISSÕES
	//Abre o arquivo
	
	// $arquivo = fopen("dados/professores.csv", "a+");

	//Escreve no arquivo
	// fwrite($arquivo, $linha);

	//Fecha o arquivo
	// fclose($arquivo);

	// echo('<meta http-equiv="refresh" content="0;url=listaProfessores.php">');