<?php 
	include("cabecalho.php");

	include("disciplinas.php");

	include("professores.php");
?>
 	<!-- conteudo principal -->
	<article class="coluna80">
		<h2> Disciplinas </h2>
		
		<section id="tabs">
				<a class="tab" id="tab1">1INFO1</a>
				<a class="tab" id="tab2">1INFO2</a>
				<a class="tab" id="tab3">1INFO3</a>

				<br></br>
								
				<section class="conteudo tab1" id="cont1">
				<section class="lista">
				<ul>
				<?php
					$lista = listaOfertas(2017,'1info1');

					foreach ($lista as $disciplina) {


					$disc = buscaDisciplina ($disciplina['Cod_disciplina']);
					$prof = buscaProfessor  ($disciplina['Cod_professor']);
	
				?>	
				<div class="lista-disciplina">
					<li><?=$disc['Nome'] ?> - <?=$prof['Nome'] ?></li>
				</div>
				<?php
					}
				?>
				</ul>
				</section>
				</section>




			<section class="conteudo tab2 escondido" id="cont2">
				<section class="lista">
				<ul>
				<?php
					$lista = listaOfertas(2017,'1info2');

					foreach ($lista as $disciplina) {

					$disc = buscaDisciplina($disciplina['Cod_disciplina']);
					$prof = buscaProfessor  ($disciplina['Cod_professor']);
				?>	
				<div class="lista-disciplina">
					<li><?=$disc['Nome'] ?> - <?=$prof['Nome'] ?></li>
				</div>
				<?php
					}
				?>
		    	 </ul>
				</section>
				</section>



			<section class="conteudo tab3 escondido" id="cont3">
				<section class="lista">
				<ul>
				<?php
					$lista = listaOfertas(2017,'1info3');

					foreach ($lista as $disciplina) {

					$disc = buscaDisciplina($disciplina['Cod_disciplina']);
					$prof = buscaProfessor  ($disciplina['Cod_professor']);
				?>	
				<div class="lista-disciplina">
					<li><?=$disc['Nome'] ?> - <?=$prof['Nome'] ?></li>
				</div>
				<?php
					}
			?>
		        </ul>
				</section>
				</section>
		</section>
	</article>


<?php
	include("rodape.php");

?>	