<?php 
	include("cabecalho.php");

	include("alunos.php");
?>

 	<!-- conteudo principal -->
	<article class="coluna80">
		<h2> Alunos </h2>

		<section id="tabs">
				<a class="tab" id="tab1" class="botao">1INFO1</a>
				<a class="tab" id="tab2" class="botao">1INFO2</a>
				<a class="tab" id="tab3" class="botao">1INFO3</a>

				<br></br>

				<section class="conteudo tab1" id="cont1" class="ativo">
				<section class="lista">
				<ul>
			<?php
				$lista = listaAlunosTurma('1info1');

				foreach ($lista as $aluno) {
			?>	
				<div class="lista-aluno">
					<li><a href="detalhaAluno.php?cod=<?=$aluno['Matricula'] ?>"> <?=$aluno['Nome'] ?></a></li>
				</div>
			<?php
				}
			?>
				 </ul>
				</section>
				</section>




			<section class="conteudo tab2 escondido" id="cont2">
				<section class="lista">
				<ul>
			<?php
				$lista = listaAlunosTurma('1info2');

				foreach ($lista as $aluno) {
			?>	
				<div class="lista-aluno">
					<li><a href="detalhaAluno.php?cod=<?=$aluno['Matricula'] ?>"> <?=$aluno['Nome'] ?></a></li>
				</div>
			<?php
				}
			?>
		    	 </ul>
				</section>
				</section>



			<section class="conteudo tab3 escondido" id="cont3">
				<section class="lista">
				<ul>
			<?php
				$lista = listaAlunosTurma('1info3');

				foreach ($lista as $aluno) {
			?>	
				<div class="lista-aluno">
					<li><a href="detalhaAluno.php?cod=<?=$aluno['Matricula'] ?>"> <?=$aluno['Nome'] ?></a></li>
				</div>
			<?php
				}
			?>
		        </ul>
				</section>
				</section>
		</section>
	</article>


		
<?php

	include("rodape.php");

?>	