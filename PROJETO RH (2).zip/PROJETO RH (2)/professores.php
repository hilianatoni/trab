<?php 

//Arquivo com funções para manipulação de dados de professores



///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////            L I S T A   P R O F E S S O R E S            ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	function listaProfessores(){

		$professores = array();

		$dados = file("dados/professores.csv");

		foreach ($dados as $posicao => $linha) {
			if ($posicao != 0) {
				$colunas = explode(",", $linha);

				$professor = array();
	       		$professor['Siape'] = $colunas[0];
				$professor['Nome']  = $colunas[1];
				$professor['Email'] = $colunas[2];
				$professor['Foto']  = $colunas[3];

				$professores[] = $professor;
			}
		}

		//olha o array aí ó!!!!1!

 
		return $professores;
	}

	

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////    B U S C A  D A D O S  D E  U M   P R O F E S S O R   ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	function buscaProfessor($codigo){
		$professor = array();

		$dados = file("dados/professores.csv");

		foreach ($dados as $linha) {

			$colunas = explode(",", $linha);

			if ($colunas[0] == $codigo) {

				$professor['Siape'] = $colunas[0];
				$professor['Nome']  = $colunas[1];
				$professor['Email'] = $colunas[2];
				$professor['Foto']  = $colunas[3];
			}
		}

		return $professor;
	}


	//$prof = buscaProfessor(1578494);
	//print_r($prof);

