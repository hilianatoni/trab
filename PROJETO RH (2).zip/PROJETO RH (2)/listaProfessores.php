<?php 
	include("cabecalho.php");
?>

 	<!-- conteudo principal -->
	<article class="coluna80">
		<h2><section class="clique"> Professores </section></h2>
		<section class="lista">
		<ul>

<?php
	if (isset($_SESSION['login'])) {
		echo('<a href="formProfessor.php"> Novo Professor... </a>');
	}
	
	include("professores.php");

	$lista = listaProfessores();

	foreach ($lista as $professor) {
?>	
		<div>
			<li><a href="detalhaProfessor.php?cod=<?=$professor['Siape'] ?>" id="osa"> <?=$professor['Nome']?></a></li>
		</div>
<?php
	}
?>
		 </ul>
		</section>
	</article>


<?php
	include("rodape.php");

?>	