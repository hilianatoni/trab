  // ESCONDER ALUNOS E DISCIPLINAS//
$(document).ready(function(){
	$(".tab").click(function(){

		
		$('.conteudo').addClass('escondido');

		var id;

		id = $(this).attr('id');

		$("."+id).removeClass('escondido');


		$(".tab").removeClass('ativo');

		
		$("#"+id).addClass('ativo');
	})
})