<?php 
	
	session_start();

	if($_SESSION['login'] == 'admin'){

?>

<!DOCTYPE html>
<html>
<head>
	<title> Acesso Restrito - Sinal de Perigo </title>
</head>
<body>
	<h2>Página de Acesso Restrito - Administrador </h2>
	<p> Nesta pagina você poderá alterar as configurações de sistema </p>
	<a href="logout.php"> Sair desta página </a>
</body>
</html>
<?php 
	}else{
		echo ("You shall not pass!!!11??11249");
	}