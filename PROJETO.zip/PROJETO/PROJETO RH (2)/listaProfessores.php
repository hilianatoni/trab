<?php 
	include("cabecalho.php");
?>

 	<!-- conteudo principal -->
	<article class="coluna80">
		<h2><section class="clique"> Professores </section></h2>
		<section class="lista">
		<ul>

<?php
	include("professores.php");

	$lista = listaProfessores();

	foreach ($lista as $professor) {
?>	
		<div class="lista-coiso">
			<li class="escondido white"><a href="detalhaProfessor.php?cod=<?=$professor['Siape'] ?>" id="osa"> <?=$professor['Nome']?></a></li>
		</div>
	<section class="moda escondido">
		<section class="fecho">X</section>
		<img src="pessoa.jpg" class="grande">
	</section>

<?php
	}
?>
		 </ul>
		</section>
	</article>


<?php
	include("rodape.php");

?>	