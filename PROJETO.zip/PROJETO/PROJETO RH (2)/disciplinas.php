<?php 

//Arquivo com funções para manipulação de dados das disciplinas



///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////            L I S T A   D I S C I P L I N O S            ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	

	function listaDisciplinas(){

		$disciplinas = array();

		$dados = file("dados/disciplinas.csv");

		foreach ($dados as $posicao => $linha) {
			if ($posicao != 0) {
				$colunas = explode(",", $linha);

				$disciplina = array();
	       		$disciplina['Codigo'] = $colunas[0];
				$disciplina['Nome']   = $colunas[1];


				$disciplinas[] = $disciplina;
			}
		}
		return $disciplinas;
}		
		//olha o array aqui ó Í!!!!1!

	


///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////            B U S C A    D I S C I P L I N O S           ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	

	function buscaDisciplina($codigo){

		$disciplina = array();

		$dados = file("dados/disciplinas.csv");

		foreach ($dados as $linha) {

			$colunas = explode(",", $linha);

			if ($colunas[0] == $codigo) {

				$disciplina['Codigo'] = $colunas[0];
				$disciplina['Nome']   = $colunas[1];
			}
		}

		return $disciplina;
	}
 		//look at the array héré Í!!!!1!




///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////                 L I S T A    O F E R T A                ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


	function listaOfertas($ano, $turma){

		$ofertas = array();

		$dados = file("dados/ofertas.csv");

		foreach ($dados as $posicao => $linha) {
			if ($posicao != 0) {
				$colunas = explode(",", $linha);
				if($colunas[1]==$turma and $colunas[0]==$ano){
					$oferta = array();
		       		$oferta['Ano']            = $colunas[0];
					$oferta['Turma']          = $colunas[1];
					$oferta['Cod_disciplina'] = $colunas[2];
					$oferta['Cod_professor']  = $colunas[3];
				
					$ofertas[] = $oferta;
				}
			}
		}
		return $ofertas;
}		
		//посмотрите на массив здéсь Н!!!!1!
	

?>



