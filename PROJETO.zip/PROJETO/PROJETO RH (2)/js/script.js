$(document).ready(function(){
	$(".clique").click(function(){
		$(".white").toggleClass("escondido");
	})

})
	

	// MODAL //
$(document).ready(function(){
	$(".lista-coiso").click(function(){
		var id;
		id = $(this).attr('id');
		$("."+id).removeClass('escondido');

		
	})

	$(".fecho").click(function(){
		$(".moda").addClass("escondido");
	})
})



    // ESCONDER ALUNOS E DISCIPLINAS//
$(document).ready(function(){
	$(".tab").click(function(){

		
		$('.conteudo').addClass('escondido');

		var id;

		id = $(this).attr('id');

		$("."+id).removeClass('escondido');


		$(".tab").removeClass('ativo');

		
		$("#"+id).addClass('ativo');
	})
})


	// ESCONDER MENU //

$(document).ready(function(){
	$(".menu").click(function(){

		
		$('.conteudo').addClass('item menu');

		var id;

		id = $(this).attr('id');

		$("."+id).removeClass('item menu');


		$(".menu").removeClass('item menu ativo');

		
		$("#"+id).addClass('item menu ativo');
	})
})