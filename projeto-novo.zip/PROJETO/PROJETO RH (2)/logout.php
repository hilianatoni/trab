<?php

	//iniciar sessão
	session_start();

	//destruir sessão
	session_destroy();

	echo ('<meta http-equiv="refresh" content="0;url=listaProfessores.php">');