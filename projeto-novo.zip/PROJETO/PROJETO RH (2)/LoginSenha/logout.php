<?php
	//iniciar sessão
	session_start();

	//destruir sessão
	session_destroy();

	echo ('<meta http-equip="refresh" content="0;url=publico.php">');