<?php
		
	include("cabecalho.php");

	//Iniciar sessão

	session_start();
	
	//Capturando valores do POST

	$login = $_POST['login'];

	$senha = $_POST['senha'];

	//Usúario 'admin' e senha 'admin'
	if($login == 'admin' && $senha == 'admin'){
?>
	<section id="vinda">
		Olá Administrador!
	</section>
<?php 
		$_SESSION['nome'] = "administrador";
		$_SESSION['login'] = "admin";

		//Redireciona para a página de acesso restrito do Administrador

		echo '<meta http-equiv="refresh" content="2;url=listaProfessores.php">';
	
	}else{
		echo "Dados Invalidos!";

		//Redireciona para a página de formulário de login

		echo '<meta http-equiv="refresh" content="2;url=listaProfessores.php">';
	}
