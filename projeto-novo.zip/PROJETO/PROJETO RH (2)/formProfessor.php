<?php 	
	include("cabecalho.php");
?>
	<article class="coluna80">
<?php 
	if (isset($_SESSION['login'])) {
?>		
		<form method="post" action="insereProfessor.php" enctype="multipart/form-data">
			<label for="siape"> SIAPE </label>
			<input type="text" name="siape">
			<br>
			<label for="nome"> Nome </label>
			<input type="text" name="nome">
			<br>
			<label for="email"> Email </label>
			<input type="email" name="email">
			<br>
			<label for="foto"> Foto </label>
			<input type="file" name="foto">
			<br>
			<input id="env" type="submit" name="gravar">
		</form>
<?php 
	}else{
	echo('<meta http-equiv="refresh"content="0;url=listaProfessores.php">');
	}
?>			
	</article>	
<?php 	
	include("rodape.php");
?>